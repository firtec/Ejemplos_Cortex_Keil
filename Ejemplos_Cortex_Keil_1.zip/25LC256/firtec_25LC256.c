
#include "stm32f4xx.h"
#include "firtec_25LC256.h"
#include "firtec_spi.h"
#include "tm_stm32f4_delay.h"

extern unsigned char datos[12];

void CS_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	// PIN NSS de SPI2
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  GPIO_SetBits(GPIOB,GPIO_Pin_12);	// Desabilita memoria
}

void Memoria_BUSY(void)
{
	unsigned char Status;
	do{
	GPIO_ResetBits(GPIOB,GPIO_Pin_12); // Habilita memoria
	SPI_TX_Byte(0x05);                //Read Status Reg OpCode
  Status = SPI_RX_Byte();               //Read Status Reg
	GPIO_SetBits(GPIOB,GPIO_Pin_12);	// Desabilita memoria	
	} while (Status & 0x01);            //Check for WIP bit Set
		
	GPIO_SetBits(GPIOB,GPIO_Pin_12);	// Desabilita memoria
}
/********************************************************************
*     Function Name:    WriteEnable                                 *
*     Return Value:     void                                        *
*     Parameters:       void                                        *
*     Description:      This routine sets the Write Enable Latch    *  
********************************************************************/
void Write_Enable(void)
{
    GPIO_ResetBits(GPIOB,GPIO_Pin_12);   //Select Device
	 // Delayms(1);
    SPI_TX_Byte(0x06);                //Write Enable OpCode
	 // Delayms(1);
    GPIO_SetBits(GPIOB,GPIO_Pin_12);     //Deselect Device
}
/********************************************************************
*     Function Name:    LDByteWriteSPI                              *
*     Parameters:       EE memory control, address and pointer 1    *
*     Description:      Writes Data Byte to SPI EE memory device    *
*                       This routine can be used for any SPI        *   
*                       EE memory device with 1 byte of address.    *
*                                                                   *  
********************************************************************/
unsigned char Byte_WriteSPI(unsigned char HighAdd, unsigned char LowAdd, unsigned char Data )
{
  
	Write_Enable();                      // Write Enable prior to Write
  //Leer_Status();                       // Check for WEL bit set
  GPIO_ResetBits(GPIOB,GPIO_Pin_12);  // Select Device
	SPI_TX_Byte (0x02); // Comando para escribir
  //Delayms(1);
  SPI_TX_Byte (LowAdd);                // write address byte to EEPROM
  SPI_TX_Byte (HighAdd);
	SPI_TX_Byte (Data);                  // Write Byte to device
  GPIO_SetBits(GPIOB,GPIO_Pin_12);    // Deselect device and initiate Write
  Memoria_BUSY();                    // Wait for Write to complete
	
  return ( 0 );
}

/********************************************************************
*     Function Name:    LDByteReadSPI                               *
*     Parameters:       EE memory control, address, pointer and     *
*                       length bytes.                               *
*     Description:      Reads data Byte from SPI EE memory device.  *
*                       This routine can be used for any SPI        *
*                       EE memory device with 1 byte of address     *
*                                                                   *
********************************************************************/  
unsigned char Byte_ReadSPI(unsigned char High_Add, unsigned char Low_Add)
{
	unsigned char dato_leido;

  GPIO_ResetBits(GPIOB,GPIO_Pin_12); // Select Device
 SPI_TX_Byte(0x03);                   // Comando para leer 
 //Delayms(1);
	SPI_TX_Byte(Low_Add);                 // WRITE word address to EEPROM
	SPI_TX_Byte(High_Add);
  dato_leido = SPI_RX_Byte();           // read in multiple bytes
  GPIO_SetBits(GPIOB,GPIO_Pin_12);  
	
	
  return dato_leido;                                 
}


