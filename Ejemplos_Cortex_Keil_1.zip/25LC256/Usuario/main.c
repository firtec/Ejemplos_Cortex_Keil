/*************************************************************
*  Nombre       : AT45DBX.c
*  Descripci�n  : Bus SPI conectado a una meoria AT45DBX041D             
*  Target       : STM32F407VG
*  ToolChain    : MDK-ARM
*  IDE          : uVision 4 
*								www.firtec.com.ar
***************************************************************/
#include "stm32f4xx.h"

#include <string.h>
#include <stdio.h>
#include "tm_stm32f4_hd44780.h"
#include "firtec_25LC256.h"
#include "firtec_spi.h"

 char str_num [9];
int main(void)
{
	unsigned char lectura =0;
//	unsigned char ID[4];

	
	TM_DELAY_Init();
	SPI_Config();
	TM_HD44780_Init(16, 2);
	//CS_Init();  // Configura chip-set de memoria
	
 
	//GPIO_Configuration();	
	//Configurar_Puerto_LCD();
	//Configura_LCD();
  TM_HD44780_Puts(0, 0,"SPI 25LC256");	  
	
	Memoria_BUSY();
	//SPI_send(0x00,0x54);
	Byte_WriteSPI(0x00,0x00,4);
	Delayms(500);
	lectura = Byte_ReadSPI(0,0);
	//lectura = SPI_read(0);
	sprintf(str_num,"%u",lectura);
  TM_HD44780_Puts(0, 1,str_num);
	
	//TM_HD44780_Puts(0, 1,"Toy aca!!!");	
	
	while (1)
	{
		__nop();
		
		//GPIO_ToggleBits(GPIOD, GPIO_Pin_15); // Todo a sido OK
		//Delay(0x5fffff);
	}
}




/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
