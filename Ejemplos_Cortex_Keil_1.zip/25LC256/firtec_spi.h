/*********************************************************************************************************
*
* File                : ws_spi.h
* Hardware Environment: 
* Build Environment   : RealView MDK-ARM  Version: 4.20
* Version             : V1.0
* By                  : 
*
*                                  (c) Copyright 2005-2011, WaveShare
*                                       http://www.waveshare.net
*                                          All Rights Reserved
*
*********************************************************************************************************/

#ifndef __SPI_H
#define __SPI_H

static void SPI_Rcc_Configuration(void);
static void GPIO_Configuration(void);
void SPI_Config(void);
void SPI_TX_Byte(unsigned char data);
unsigned char SPI_RX_Byte(void);
unsigned char SPI_read(unsigned short address);
void SPI_send(unsigned char address, unsigned char data);

#endif /*__SPI_H*/
