/*********************************************************************************************************
*
* File                : firtec_25LC256.h
* Hardware Environment: 
* Build Environment   : MDK-ARM  Version: 5.20
* www.firtec.com.ar
*
*********************************************************************************************************/

#ifndef _FIRTEC_25LC256_H
#define _FIRTEC_25LC256_H

void CS_Init(void);
void Memoria_BUSY(void);
void Leer_Status(void);
void Write_Enable(void);
unsigned char Byte_WriteSPI(unsigned char HighAdd, unsigned char LowAdd, unsigned char Data);
unsigned char Byte_ReadSPI(unsigned char High_Add, unsigned char Low_Add);

#endif 

