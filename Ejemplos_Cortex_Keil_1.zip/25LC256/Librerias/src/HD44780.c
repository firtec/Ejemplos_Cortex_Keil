/*************************************************************
*  Nombre       : HD44780.c
*  Descripci�n  : Driver para LCD Hitachi44780 20*2  (v3)         
*  Target       : STM32F4xx
*  ToolChain    : MDK-ARM
*	 www.firtec.com.ar
***************************************************************/
#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"    // Driver de perif�ricos
#include "stm32f4xx_gpio.h"		// Driver de perif�ricos
#include "HD44780.h"

#define   LCD_OUT   GPIOB->ODR  // LCD usar� el puerto B

// Conectar RW a GND.

#define     LCD_PIN_RS            GPIO_Pin_0          // P1.0
#define     LCD_PIN_EN            GPIO_Pin_1          // P1.1
#define     LCD_PIN_D7            GPIO_Pin_7          // P1.7
#define     LCD_PIN_D6            GPIO_Pin_6          // P1.6
#define     LCD_PIN_D5            GPIO_Pin_5          // P1.5
#define     LCD_PIN_D4            GPIO_Pin_4          // P1.4
#define     delay      1000      // SYSCLK 168Mz
GPIO_InitTypeDef  GPIO_InitStructure;
#define     LCD_PIN_MASK  ((LCD_PIN_RS | LCD_PIN_EN | LCD_PIN_D7 | LCD_PIN_D6 | LCD_PIN_D5 | LCD_PIN_D4))

#define     FALSE                 0
#define     TRUE                  1



//##############################################################
//       FUNCIONES DEL LCD HITACHI44780 
//##############################################################
/*************** Configurar_Puerto() **************************/
/* Esta funci�n configura el puerto para el LCD. */
/* Argumentos: Ninguno */
/* Retorna: Nada  */
/*************************************************************/
void Configurar_Puerto_LCD(){
	 //LCD_OUT |= (LCD_PIN_MASK);
	  LCD_OUT &= ~(LCD_PIN_MASK);
	 	IniRetardo_LCD();
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin =GPIO_Pin_0 | GPIO_Pin_1| GPIO_Pin_4 | GPIO_Pin_5| GPIO_Pin_6| GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	   //GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    //GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    LCD_OUT &= ~(LCD_PIN_MASK);	
	  
}
/*************** __delay_cycles_LCD **************************/
/* Esta funci�n genera los tiempos para el LCD. */
/* Argumentos: Cantidad de ciclos de CPU a esperar */
/* Retorna: Nada  */
/*************************************************************/
void __delay_cycles_LCD(__IO uint32_t nCount) {
  while(nCount--) {
  }
}
/*************** IniRetardo_LCD ************************/
/* Esta funci�n retarda el arranque para el LCD. */
/* Argumentos: Ninguno */
/* Retorna: Nada  */
/********************************************************/
void IniRetardo_LCD(){
	unsigned int a = 0;
            while(a<500)
            {
                __delay_cycles_LCD(100000);
                a++;
            }
}
/***************** Hab_LCD ************************/
/* Esta funci�n controla el pin E del LCD. */
/* Argumentos: Ninguno */
/* Retorna: Nada  */
/**************************************************/
void Hab_LCD()
{
  	LCD_OUT &= ~LCD_PIN_EN;		// Pin E es 0
   // __delay_cycles_LCD(delay);
    LCD_OUT |= LCD_PIN_EN;			// Pin E es 1
    __delay_cycles_LCD(delay);	// Espero 
    LCD_OUT &= ~LCD_PIN_EN;			// Pin E es 0
	  __delay_cycles_LCD(delay);	// Espero
	   //LCD_OUT &= ~LCD_PIN_RS;	
	
}
/******************** EnviarByte ************************/
/* Esta funci�n env�a un Byte al LCD */
/* Argumentos: el propio Byte y si es control o dato */
/* Retorna: Nada  */
/*********************************************************/
void EnviarByte(char ByteToSend, int IsData)
{
    LCD_OUT &= (~LCD_PIN_MASK); // Limpio el BUS
	  
    LCD_OUT |= (ByteToSend & 0xF0); // Enmascara la parte alta del dato
    if (IsData == TRUE){            // Pregunto si es Dato o Comando
        LCD_OUT |= LCD_PIN_RS;		  // Si dato RS es 1
    }
    else{
        LCD_OUT &= ~LCD_PIN_RS;	    // Si comando RS 0
    }
      Hab_LCD(); // Habilito para enviar la parte alta
		LCD_OUT &= (~LCD_PIN_MASK);
//---------------------------------------------------------------------------		
      LCD_OUT |= ((ByteToSend & 0x0F) << 4); // Enmascaro la parte baja y desplazo para enviarla
    if (IsData == TRUE){										// Pregunto si es dato o comando
        LCD_OUT |= LCD_PIN_RS;
    }
    else{
        LCD_OUT &= ~LCD_PIN_RS;
    }
        Hab_LCD();	// Habilito para enviar la parte baja
		 LCD_OUT &= (~LCD_PIN_MASK); // Limpio el Bus
		LCD_OUT &= ~LCD_PIN_RS;  
	   
}
/***************** Cursor ************************/
/* Esta funci�n controla la pos. del cursor */
/* Argumentos: l�nea X e Y */
/* Retorna: Nada  */
/**************************************************/
void Cursor(char Row, char Col)
{
    char address;
    if (Row == 0){
        address = 0;
    }
    else
    {
        address = 0x40;
    }
    address |= Col;
    EnviarByte(0x80 | address, FALSE);
}
/************* LimpiarPantalla ********************************/
/* Esta funci�n limpia la pantalla y coloca cursor al inicio */
/* Argumentos: ninguno */
/* Retorna: Nada  */
/**************************************************************/
void LimpiarPantalla()
{
    EnviarByte(0x01, FALSE);
	 __delay_cycles_LCD(30000);	
	  EnviarByte(0x02, FALSE);
   __delay_cycles_LCD(30000);		
   
}
/****************** Configura_LCD ********************************/
/* Esta funci�n configura el LCD en 4 bits + cursor por defecto */
/* Argumentos: Ninguno */
/* Retorna: Nada  */
/*****************************************************************/
void Configura_LCD(void){
   LCD_OUT &= ~(LCD_PIN_MASK); // Lineas puestas a 0
	 //LCD_OUT &= ~(LCD_PIN_MASK);
	LCD_OUT |= LCD_PIN_RS;
 	 LCD_OUT |= LCD_PIN_EN;
	 LCD_OUT |= LCD_PIN_EN;

	 //
	__delay_cycles_LCD(20000);
	  LCD_OUT &= ~LCD_PIN_RS;	
	  LCD_OUT &= ~LCD_PIN_EN;
	  LCD_OUT &= ~LCD_PIN_EN;
	
	__delay_cycles_LCD(20000); 
  	LCD_OUT = 0x20;           // Indico que seran 4 bits
	  LCD_OUT = 0x20;  
	 // LCD_OUT = 0x20;  
		Hab_LCD();
		EnviarByte(0x28, FALSE);
	  EnviarByte(0x28, FALSE);
	//  EnviarByte(0x28, FALSE);
	 //EnviarByte(0x0F, FALSE); // Cursor titilando
   //EnviarByte(0x0E, FALSE); // Cursor Peque�o
		EnviarByte(0x0C, FALSE);  // Cursor invisible
		EnviarByte(0x06, FALSE);  // Cursor incrementa a la derecha
		LimpiarPantalla();
	
		
	  
}
/****************** PrintStr()********************************/
/* Esta funci�n imprime una cadena desde la FLASH en el LCD */
/* Argumentos: puntero al inicio de la cadena */
/* Retorna: Nada  */
/*****************************************************************/
void PrintStr(char *Text)
{
    char *c;
    c = Text;
    while ((c != 0) && (*c != 0))
    {
        EnviarByte(*c, TRUE);
        c++;
    }
}
/******************** lcd_putc () ********************************/
/* Esta funci�n imprime un ASCII en el LCD */
/* Argumentos: puntero al inicio de la cadena */
/* Retorna: Nada  */
/*****************************************************************/
void lcd_putc(unsigned char c){
	
	EnviarByte(c, TRUE);
		
  }
/******************** lcd_puts() ******************************/
/* Esta funci�n imprime una cadena desde la RAM con formato   */
/* Argumentos: puntero al inicio de la cadena */
/* Retorna: Nada  */
/**************************************************************/
void lcd_puts(char *ptr){

	while(*ptr){
		lcd_putc(*ptr++);
	}
}
