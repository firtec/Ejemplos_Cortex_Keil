/*******************************************************************************
*  Nombre       : CAN_RX_TX.c
*  Descripci�n  : Envia datos por CAN1 y los recibe por CAN2.             
*  Target       : STM32F407VG
*  ToolChain    : MDK-ARM
*  IDE          : uVision 4 
*		      www.firtec.com.ar
*******************************************************************************/

#include "stm32f4xx.h"
#include "usart.h"
#include "config.h"
#include <stdlib.h>
#include <stdio.h>

#define USARTx      					USART2 			
#define USER_KEY_Port					GPIOA 			// Puerto para el boton de usuario
#define USER_KEY_Pin					GPIO_Pin_0	// Boton en PA0 
#define USER_KEY_RCC_AHBPeriph			RCC_AHB1Periph_GPIOA

CAN_InitTypeDef        CAN_InitStructure;
CAN_FilterInitTypeDef  CAN_FilterInitStructure;
CanTxMsg TxMessage;

uint16_t CAN1_ID;
uint8_t CAN1_Dato0,CAN1_Dato1,CAN1_Dato2,CAN1_Dato3,CAN1_Dato4,CAN1_Dato5,CAN1_Dato6,CAN1_Dato7;

uint16_t CAN2_ID;
uint8_t CAN2_Dato0,CAN2_Dato1,CAN2_Dato2,CAN2_Dato3,CAN2_Dato4,CAN2_Dato5,CAN2_Dato6,CAN2_Dato7;

__IO uint8_t Bandera_Can1,Bandera_Can2;

void CAN1_Config(void);
void CAN2_Config(void);
void NVIC_Config(void);
void Can1_Escribe_Byte(uint16_t ID);
void Can2_Escribe_Byte(uint16_t ID);
void Key_Config(void);

//##################################################
//  Funci�n para enviar cadenas por la USART
//##################################################
void Enviar_String(const char *s)
{
  while(*s)
  {
    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    USART_SendData(USART2, *s++);
  }
}
//###################################################
//  Funci�n principal del programa
//###################################################
int main(void)
{
  uint8_t error_can=0;
  USART_Configuration(); 	// Configura la USART
		Enviar_String("CAN-Bus Test \r\n");
			Key_Config(); 				// Configura el Boton de usuario
				CAN1_Config();			// Configura el CAN1
					CAN2_Config();		// Configura el CAN2
						NVIC_Config();	// Configura las interrupciones
  
//############## Bucle Infinito #############	
  while (1){
		
while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
	  Can1_Escribe_Byte(0x123);
		//Enviar_String("Boton OK  \r\n");
	  while(Bandera_Can2!= ENABLE);
    Bandera_Can2 = DISABLE;	 
Enviar_String ("Datos recibidos en CAN2 \r\n");
			USART_SendData(USART2,CAN2_Dato0);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN2_Dato1);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN2_Dato2);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN2_Dato3);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN2_Dato4);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN2_Dato5);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN2_Dato6);	
			Enviar_String(" \r\n");		 
if(CAN2_ID!=0x123 || 		// Se verifica si hay errores
				CAN2_Dato0!=CAN1_Dato0 || 
				CAN2_Dato1!=CAN1_Dato1 || 
				CAN2_Dato2!=CAN1_Dato2 || 
				CAN2_Dato3!=CAN1_Dato3 || 
				CAN2_Dato4!=CAN1_Dato4 || 
				CAN2_Dato5!=CAN1_Dato5 || 
				CAN2_Dato6!=CAN1_Dato6 || 
				CAN2_Dato7!=CAN1_Dato7 )
{Enviar_String("CAN1 ERROR!! \r\n");error_can=1;}
    Can2_Escribe_Byte(0x321);
	  while(Bandera_Can1!= ENABLE);
    Bandera_Can1 = DISABLE; 
		Enviar_String ("Datos recibidos en CAN1 \r\n");
			USART_SendData(USART2,CAN1_Dato0);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN1_Dato1);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN1_Dato2);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN1_Dato3);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN1_Dato4);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN1_Dato5);
			Enviar_String(" \r\n");
			USART_SendData(USART2,CAN1_Dato6);	
			//Enviar_String(" \r\n");		 
if(CAN1_ID!=0x321 ||  		// Se verifica si hay errores
				CAN1_Dato0!=CAN2_Dato0 || 
				CAN1_Dato1!=CAN2_Dato1 || 
				CAN1_Dato2!=CAN2_Dato2 || 
				CAN1_Dato3!=CAN2_Dato3 || 
				CAN1_Dato4!=CAN2_Dato4 || 
				CAN1_Dato5!=CAN2_Dato5 || 
				CAN1_Dato6!=CAN2_Dato6 || 
				CAN1_Dato7!=CAN2_Dato7 )
				{Enviar_String("CAN2 ERROR \r\n");error_can=1;}
				while(!GPIO_ReadInputDataBit(USER_KEY_Port,USER_KEY_Pin));
					if(error_can==0){
							Enviar_String("CAN1 CAN2 OK !! \r\n");
		}
  }
}
//#############################################################
// Configura el Boton
//#############################################################
void Key_Config(void)
{
	GPIO_InitTypeDef   GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);  // reloj para el puerto del pulsador

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;        // PA0 es el boton de usuario
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;     
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
 	//GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL; 
  GPIO_Init(GPIOA, &GPIO_InitStructure);   
}
//#########################################################################
// Configura el funcionamiento del CAN1
//#########################################################################
void CAN1_Config(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure; // Estructura que maneja los puertos.
// Conecta el reloj AHB1 al puerto B
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
// Conecta los pines PB8 - (RX) y PB9 (TX) al CAN1
		GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_CAN1);
		GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_CAN1);   
  
// Conecta los pines RX y TX para el CAN1
			GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
			GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
			GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
			GPIO_Init(GPIOB, &GPIO_InitStructure);
// Conecta el reloj al CAN1
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);
  
			CAN_DeInit(CAN1); // Registro de inicio para el CAN1
			CAN_StructInit(&CAN_InitStructure);  // Estructura del CAN1
			CAN_InitStructure.CAN_TTCM = DISABLE;
			CAN_InitStructure.CAN_ABOM = DISABLE;
			CAN_InitStructure.CAN_AWUM = DISABLE;
			CAN_InitStructure.CAN_NART = DISABLE;
			CAN_InitStructure.CAN_RFLM = DISABLE;
			CAN_InitStructure.CAN_TXFP = DISABLE;
			CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;
			CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;
		
// CAN Baudios = 1 MBps (CK a 30 MHz)
			CAN_InitStructure.CAN_BS1 = CAN_BS1_6tq;
			CAN_InitStructure.CAN_BS2 = CAN_BS2_8tq;
			CAN_InitStructure.CAN_Prescaler = 2;		
	    CAN_Init(CAN1, &CAN_InitStructure); // Valida la configuraci�n

// Configura el filtro para los mensajes que atender� el CAN1
  CAN_FilterInitStructure.CAN_FilterNumber = 0; //0..13 para CAN1
  CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
  CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
  CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterFIFOAssignment = 0;
  CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
  CAN_FilterInit(&CAN_FilterInitStructure);
  
// Prepara la estructura del mensaje a transmitir en el CAN1
  TxMessage.StdId = 0x321;  // M�scara del mensaje del CAN1
  TxMessage.ExtId = 0x01;
  TxMessage.RTR = CAN_RTR_DATA;
  TxMessage.IDE = CAN_ID_STD;
  TxMessage.DLC = 1;
  
// Habilita FIFO para mensajes pendientes
  CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);
}
//#########################################################################
// Configura el funcionamiento del CAN2
//#########################################################################
void CAN2_Config(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  // Conecta los pines PB12 - (RX) y PB6 (TX) al CAN2
 	GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_CAN2);
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_CAN2); 
  
// Configura los pines del CAN2
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
 
// Habilita el reloj para el CAN2
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);
  
  CAN_DeInit(CAN2);  // Registro de inicio para el CAN2
  CAN_StructInit(&CAN_InitStructure); // Estructura del CAN2

// Configura el m�dulo CAN2
  CAN_InitStructure.CAN_TTCM = DISABLE;
  CAN_InitStructure.CAN_ABOM = DISABLE;
  CAN_InitStructure.CAN_AWUM = DISABLE;
  CAN_InitStructure.CAN_NART = DISABLE;
  CAN_InitStructure.CAN_RFLM = DISABLE;
  CAN_InitStructure.CAN_TXFP = DISABLE;
  CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;
  CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;
    
  /* CAN Baudrate = 1MBps (CAN clocked at 30 MHz) */
  CAN_InitStructure.CAN_BS1 = CAN_BS1_6tq;
  CAN_InitStructure.CAN_BS2 = CAN_BS2_8tq;
  CAN_InitStructure.CAN_Prescaler = 2;
  CAN_Init(CAN2, &CAN_InitStructure);
	
// Configura el filtro para los mensajes que atender� el CAN2
  CAN_FilterInitStructure.CAN_FilterNumber = 14; // 14..27 para CAN2
  CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
  CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
  CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
  CAN_FilterInitStructure.CAN_FilterFIFOAssignment = 0;
  CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
  CAN_FilterInit(&CAN_FilterInitStructure);
  
 // Prepara la estructura del mensaje a transmitir en el CAN2
  TxMessage.StdId = 0x00;  // M�scara del mensaje del CAN2
  TxMessage.ExtId = 0x01;
  TxMessage.RTR = CAN_RTR_DATA;
  TxMessage.IDE = CAN_ID_STD;
  TxMessage.DLC = 1;
  
// Habilita FIFO para mensajes pendientes
  CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
}
//##################################################
// Cobfigura las interrupciones de los dos CAN
//##################################################
void NVIC_Config(void)
{
  NVIC_InitTypeDef  NVIC_InitStructure;
  NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  NVIC_InitStructure.NVIC_IRQChannel = CAN2_RX0_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}			
//##################################################
//     CAN1 Escribe datos en el bus
//##################################################
void Can1_Escribe_Byte(uint16_t ID)
{
  CanTxMsg TxMessage;
	// Datos a transmitir por CAN1 (8 BYTES ABCDEFG)
	CAN1_Dato0=65;  CAN1_Dato1=66;  // A - B
  CAN1_Dato2=67;  CAN1_Dato3=68;  // C - D
  CAN1_Dato4=69;  CAN1_Dato5=70;  // E - F
  CAN1_Dato6=71;  CAN1_Dato7=72;  // G - H 
// Transmite los datos con su indentificador
  TxMessage.StdId = ID;
//TxMessage.ExtId = 0x00;
  TxMessage.RTR = CAN_RTR_DATA;
  TxMessage.IDE = CAN_ID_STD;
  TxMessage.DLC = 8;  // Se envian 8 Bytes
  TxMessage.Data[0] = CAN1_Dato0;    
  TxMessage.Data[1] = CAN1_Dato1;    
  TxMessage.Data[2] = CAN1_Dato2;    
  TxMessage.Data[3] = CAN1_Dato3;    
  TxMessage.Data[4] = CAN1_Dato4;    
  TxMessage.Data[5] = CAN1_Dato5;     
  TxMessage.Data[6] = CAN1_Dato6;    
  TxMessage.Data[7] = CAN1_Dato7;      
  CAN_Transmit(CAN1,&TxMessage);
}
//##################################################
//     CAN2 Escribe datos en el bus
//##################################################
void Can2_Escribe_Byte(uint16_t ID)
{
  CanTxMsg TxMessage;
// Datos a transmitir  por CAN2(8 BYTES 01234567)
  CAN2_Dato0=0x30;  CAN2_Dato1=0x31;  // 0 - 1
  CAN2_Dato2=0X32;  CAN2_Dato3=0X33;  // 2 - 3
  CAN2_Dato4=0X34;  CAN2_Dato5=0X35;  // 4 - 5
  CAN2_Dato6=0X36;  CAN2_Dato7=0X37;  // 6 - 7
// Transmite los datos y su identidficador
  TxMessage.StdId = ID;
  TxMessage.RTR = CAN_RTR_DATA;
  TxMessage.IDE = CAN_ID_STD;
  TxMessage.DLC = 8;  // Cantidad de BYTES a transmitir
	//TxMessage.DLC = 6;
  TxMessage.Data[0] = CAN2_Dato0;    
  TxMessage.Data[1] = CAN2_Dato1;    
  TxMessage.Data[2] = CAN2_Dato2;    
  TxMessage.Data[3] = CAN2_Dato3;    
  TxMessage.Data[4] = CAN2_Dato4;    
  TxMessage.Data[5] = CAN2_Dato5;     
  TxMessage.Data[6] = CAN2_Dato6;    
  TxMessage.Data[7] = CAN2_Dato7;      
  CAN_Transmit(CAN2,&TxMessage);
}
//#####################################################
// Secci�n de Interrupci�nes para los receptores CANx
//#####################################################

void CAN1_RX0_IRQHandler(void)  // CAN RX
{
  CanRxMsg RxMessage;
  CAN_Receive(CAN1,CAN_FIFO0, &RxMessage);
  CAN1_ID=RxMessage.StdId;
  CAN1_Dato0=RxMessage.Data[0];
  CAN1_Dato1=RxMessage.Data[1];
  CAN1_Dato2=RxMessage.Data[2];
  CAN1_Dato3=RxMessage.Data[3];
  CAN1_Dato4=RxMessage.Data[4];
  CAN1_Dato5=RxMessage.Data[5];
  CAN1_Dato6=RxMessage.Data[6];
  CAN1_Dato7=RxMessage.Data[7];
  CAN_ClearITPendingBit(CAN1,CAN_IT_FMP0);
  Bandera_Can1 = ENABLE;
}
//--------------------------------------
void CAN2_RX0_IRQHandler(void)  // CAN2 RX
{  
  CanRxMsg RxMessage;
  CAN_Receive(CAN2,CAN_FIFO0, &RxMessage);
  CAN2_ID=RxMessage.StdId;
  CAN2_Dato0=RxMessage.Data[0];
  CAN2_Dato1=RxMessage.Data[1];
  CAN2_Dato2=RxMessage.Data[2];
  CAN2_Dato3=RxMessage.Data[3];
  CAN2_Dato4=RxMessage.Data[4];
  CAN2_Dato5=RxMessage.Data[5];
  CAN2_Dato6=RxMessage.Data[6];
  CAN2_Dato7=RxMessage.Data[7];
  CAN_ClearITPendingBit(CAN2,CAN_IT_FMP0);
  Bandera_Can2 = ENABLE;
}

//------------------- www.firtec.com.ar [2013] ---------------
