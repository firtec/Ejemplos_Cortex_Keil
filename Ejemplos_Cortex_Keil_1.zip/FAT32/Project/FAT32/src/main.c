/********************************************************************
*  Nombre       : FAT.c
*  Descripci�n  : Manejo de un sistema de archivos FAT en memoria SD 
*  								La memoria debe estar ya formateada en FAT16/FAT32
*									Debido al tama�o de variable que este programa usa
*									para direccionar la memoria solo llega a 2GB. Para
*									extender su capacidad aumentar el tama�o de las 
*									variables de direcci�n.
*  Target       : STM32F407VG
*  ToolChain    : MDK-ARM
*  IDE          : uVision 5
*					www.firtec.com.ar
********************************************************************/

#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32f4_discovery_sdio_sd.h"
#include "stm32f4_discovery_debug.h"
#include "ff.h"

// Variables usadas por el sistema de archivos.
SD_Error Status = SD_OK;
FATFS filesystem;		
FRESULT ret;			  
FIL file;				   
DIR dir;				    
FILINFO fno;			  
UINT bw, br;

uint8_t buff[128];

// Prototipos de funciones
static void Delay(__IO uint32_t nCount);
static void fault_err (FRESULT rc);

///////// FUNCION PRINCIPAL DEL PROGRAMA ///////////
int main(void)
{
  STM32f4_Discovery_Debug_Init();
  STM_EVAL_LEDInit(LED3);
  STM_EVAL_LEDInit(LED6);
	printf("\n\r");

	// Monta el sistema de archivos FAT.
  if (f_mount(0, &filesystem) != FR_OK) {
    printf("f_mount error \n\r");
		while(1);
  }
	
  Delay(10);	

  printf("Abriendo el archivo (Mensaje.txt) \n\r");
  ret = f_open(&file, "Mensaje.txt", FA_READ);
  if (ret) {
    printf("No existe el archivo (Mensaje.txt)\n\r");
  } else {
    printf("El contenido del archivo es el siguiente: \n\r");
    for (;;) {
      ret = f_read(&file, buff, sizeof(buff), &br);	// Lee el contenido del archivo.
      if (ret || !br) {
        break;			// Error en marca de fin de archivo.
      }
      buff[br] = 0;
      printf("%s",buff);
      printf("\n\r");
    }
    if (ret) {
      printf("Error en la lectura del archivo \n\r");
      fault_err(ret);
    }

    printf("Cerrando el archivo \n\r");
    ret = f_close(&file);
    if (ret) {
      printf("Error al cerrar el archivo \n\r");
    }
  }
printf("----------------------\n\r");	
	
	
  Delay(50);	
  printf("Creando un nuevo archivo (hola.txt)\n\r");
  ret = f_open(&file, "HOLA.TXT", FA_WRITE | FA_CREATE_ALWAYS);
  if (ret) {
    printf("Error al crear el nuevo archivo \n\r");
    fault_err(ret);
  } else {
    printf("Escribiendo texto dentro del archivo (hola.txt)\n\r");
    ret = f_write(&file, "Manejando archivos con FAT", 26, &bw);
    if (ret) {
      printf("Error al escribir el texto \n\r");
    } else {
      printf("%u Bytes escritos \n\r", bw);
    }
    Delay(50);
    printf("Cerrando el archivo \n\r");
    ret = f_close(&file);
    if (ret) {
      printf("Error al cerrar el archivo hola.txt \n\r");			
    }
  }
printf("----------------------\n\r");				
  Delay(50);	
  printf("Abriendo el archivo Hola.txt \n\r");
  ret = f_open(&file, "HOLA.TXT", FA_READ);
  if (ret) {
    printf("Error al abrir el archivo \n\r");
  } else {
    printf("El contenido del archivo Hola.txt es el siguiente:\n\r");
    for (;;) {
      ret = f_read(&file, buff, sizeof(buff), &br);	
      if (ret || !br) {
        break;			
      }
      buff[br] = 0;
      printf("%s",buff);
      printf("\n\r");
    }
    if (ret) {
      printf("Error al intentar leer Hola.txt \n\r");
      fault_err(ret);
    }

    printf("Cerrando el archivo Hola.txt \n\r");
    ret = f_close(&file);
    if (ret) {
      printf("Error al intentar cerrar el archivo Hola.txt \n\r");
    }
  }
printf("----------------------\n\r");		
 
  Delay(50);	
  printf("Abriendo el directorio raiz \n\r");
  ret = f_opendir(&dir, "");
  if (ret) {
    printf("Error al intenar abrir el directorio raiz\n\r");	
  } else {
    printf("El directorio raiz contiene los siguientes datos...\n\r");
    for (;;) {
      ret = f_readdir(&dir, &fno);// Lee el contenido del directorio raiz
      if (ret || !fno.fname[0]) {
        break;	
      }
      if (fno.fattrib & AM_DIR) {
        printf("  <dir>  %s\n\r", fno.fname);
      } else {
        printf("%8lu  %s\n\r", fno.fsize, fno.fname);
      }
    }
    if (ret) {
      printf("Error leyendo directorio\n\r");
      fault_err(ret);
    }
  }
printf("------------------------------------\n\r");	  
	Delay(50);	
  printf("Prueba completada. \n\r");

  while (1) {  // Bucle infinito.
    STM_EVAL_LEDToggle(LED3);
    Delay(100);	
  }
}

/////////////////////////////////////////////////////////////
// Esta funci�n captura los errores al intentar el acceso 
// a la memoria SD.
//////////////////////////////////////////////////////////////
static void fault_err (FRESULT rc)
{
  const char *str =
                    "OK\0" "DISK_ERR\0" "INT_ERR\0" "MEMORIA_NO_OK\0" "NO_FILE\0" "NO_PATH\0"
                    "INVALID_NAME\0" "DENIED\0" "EXIST\0" "INVALID_OBJECT\0" "WRITE_PROTECTED\0"
                    "INVALID_DRIVE\0" "NOT_ENABLED\0" "NO_FILE_SYSTEM\0" "MKFS_ABORTED\0" "TIMEOUT\0"
                    "LOCKED\0" "NOT_ENOUGH_CORE\0" "TOO_MANY_OPEN_FILES\0";
  FRESULT i;

  for (i = (FRESULT)0; i != rc && *str; i++) {
    while (*str++) ;
  }
	printf("%s\n\r", str);
  //printf("rc=%u FR_%s\n\r", (UINT)rc, str);
  STM_EVAL_LEDOn(LED6);
  while(1);
}

/////////////////////////////////////////////////
//  Funci�n para el retardo de tiempo.
////////////////////////////////////////////////
static void Delay(__IO uint32_t nCount)
{
  __IO uint32_t index = 0; 
  for (index = (100000 * nCount); index != 0; index--);
}


/******************** COPYRIGHT 2012 Embest Tech. Co., Ltd.*****END OF FILE****/
