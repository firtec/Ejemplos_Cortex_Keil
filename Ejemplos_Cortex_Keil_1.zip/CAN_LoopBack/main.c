/********************************************************************
*  Nombre       : CAN_LoopBack.c
*  Descripci�n  : Verifica el funcionamiento en modo LoopBack del CAN1
*                 del puerto interno del Cortex M4 (Sin la capa f�sica)
*  Target       : STM32F407VG
*  ToolChain    : MDK-ARM
*  IDE          : uVision 4 
*	 www.firtec.com.ar
*
**********************************************************************/
#include "stm32f4xx_rcc.h" // Cabeceras proporcionadas por St 
#include "stm32f4xx_gpio.h" // para simplificar el uso de los perif�ricos.
#include <stdio.h>

#define USARTx      USART2

#define USE_CAN1 
//#define USE_CAN2 

#ifdef  USE_CAN1
  #define CANx                       CAN1
  #define CAN_CLK                    RCC_APB1Periph_CAN1
  #define CAN_RX_PIN                 GPIO_Pin_8
  #define CAN_TX_PIN                 GPIO_Pin_9
  #define CAN_GPIO_PUERTO            GPIOB
  #define CAN_GPIO_CLK               RCC_AHB1Periph_GPIOB
  #define CAN_AF_PUERTO              GPIO_AF_CAN1
  #define CAN_RX_PUERTO              GPIO_PinSource8
  #define CAN_TX_PUERTO              GPIO_PinSource9
#else /*USE_CAN2*/
  #define CANx                       CAN2
  #define CAN_CLK                    (RCC_APB1Periph_CAN1 | RCC_APB1Periph_CAN2)
  #define CAN_RX_PIN                 GPIO_Pin_12
  #define CAN_TX_PIN                 GPIO_Pin_6  
  #define CAN_GPIO_PUERTO            GPIOB
  #define CAN_GPIO_CLK               RCC_AHB1Periph_GPIOB
  #define CAN_AF_PUERTO              GPIO_AF_CAN2
  #define CAN_RX_PUERTO              GPIO_PinSource12
  #define CAN_TX_PUERTO              GPIO_PinSource13
#endif  /* USE_CAN1 */

__IO uint32_t Result = 0; // Variable para evaluar el resultado de la ISR del CAN

void NVIC_Configuration(void); // Funci�n para la ISR del CAN
int CAN_Polling(void);				 // Interroga sin ISR	
int CAN_Interrupt(void);			 // Interroga con ISR
void GPIO_Configuration(void); // Configura los pines del CAN

/*********************************************************************************
* Funci�n     : GPIO_Configuration
* Descripci�n : Configura los pines y reloj del puerto B y los vincula al CAN1
* PB8 - RX
* PB9 - TX
*********************************************************************************/
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
 
	RCC_AHB1PeriphClockCmd(CAN_GPIO_CLK, ENABLE);
  
  /* CAN1 Periph clock enable */
  RCC_APB1PeriphClockCmd(CAN_CLK, ENABLE);						 
  
  /* Configure CANx pin: TX */
  GPIO_InitStructure.GPIO_Pin = CAN_RX_PIN|CAN_TX_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF; 
	 GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; 
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
	GPIO_PinAFConfig(CAN_GPIO_PUERTO, CAN_RX_PUERTO, GPIO_AF_CAN1);
	GPIO_PinAFConfig(CAN_GPIO_PUERTO, CAN_TX_PUERTO, GPIO_AF_CAN1);
}
/*********************************************************************************
* Funci�n     : Enviar_String
* Descripci�n : Envia una cadena por el puerto serial 
*********************************************************************************/
void Enviar_String(const char *s)
{
  while(*s)
  {
    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    USART_SendData(USARTx, *s++);
  }
}
/****************************************************************************
* Funci�n     : Config_USARTx
* Descripci�n : Configura los los pines y el modula USART
****************************************************************************/
void Config_USARTx(void){  // Esta funcion inicializa el perif�rico USART2
	
  // TX=GPIOA_Pin_2 (RX)
  // RX=GPIOA_Pin_3 (TX)
	
  GPIO_InitTypeDef GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure;
// Habilita los pines de GPIO para la USARTx
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);   
// Habilita el reloj para UARTx
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
// Conecta los pines del puerto a la USARTx
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource2 ,GPIO_AF_USART2); //TX
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource3 ,GPIO_AF_USART2); //RX
   
  //Configure the GPIO Pins
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; 
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
   
  //Initialize the USART
  USART_InitStructure.USART_BaudRate = 115200;//9600;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USARTx, &USART_InitStructure);
  
// Finalmente se habilita la USART2
	 USART_Cmd(USARTx, ENABLE);
}
//*********************** FUNCION PRINCIPAL ***********************
int main(void) {
	int TestRx;

GPIO_Configuration();	
Config_USARTx(); 
	Enviar_String("CAN-Bus Test modo loopback e interrupci�n \r\n"); 
	Enviar_String("========================================= \r\n");
	NVIC_Configuration();
// CAN transmite y recibe en modo loopback
TestRx = CAN_Polling(); // Funci�n que TX y RX sin interrupci�n
				if (TestRx == DISABLE)
		{
				Enviar_String("CAN-Bus modo loopback NO DETECTADO \r\n");
		}
  else
  {
				Enviar_String("CAN-Bus modo loopback DETECTADO \r\n");
  }
//----------------------------------------------------------------	
// CAN transmite y recibe por interrupcion en modo loopback
TestRx = CAN_Interrupt(); // Funci�n que TX y RX por interrupci�n
				if (TestRx == DISABLE)
  {
				Enviar_String("CAN-Bus ISR en modo loopback  NO DETECTADO \r\n");
  }
				else
  {
				Enviar_String("CAN-Bus ISR en modo loopback DETECTADO \r\n");
  }
				Enviar_String("========================================= \r\n");
  while (1){   
  // Espera por la interrupci�n.
  }
}
/****************************************************************************
* Funci�n     : NVIC_Configuration
* Descripci�n : Configura los vectores de interrupci�n para el CAN
****************************************************************************/
void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

// Habilita la interrupci�n del receptor CAN1
  NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}
/***************************************************************************
* Funci�n        : CAN_Polling
* Descrpci�n     : Configura el CAN para TX y RX sin interrupci�n.
* Retorna        : PASSED si todo es OK, FAILED en otro caso
****************************************************************************/
int CAN_Polling(void)
{
  CAN_InitTypeDef        CAN_InitStructure;
  CAN_FilterInitTypeDef  CAN_FilterInitStructure;
  CanTxMsg TxMessage;
  CanRxMsg RxMessage;
  uint32_t i = 0;
  uint8_t TransmitMailbox = 0;

	// Se configura el CAN1
  CAN_DeInit(CAN1);
  CAN_StructInit(&CAN_InitStructure);

			CAN_InitStructure.CAN_TTCM=DISABLE;
			CAN_InitStructure.CAN_ABOM=DISABLE;
			CAN_InitStructure.CAN_AWUM=DISABLE;
			CAN_InitStructure.CAN_NART=DISABLE;
			CAN_InitStructure.CAN_RFLM=DISABLE;
			CAN_InitStructure.CAN_TXFP=DISABLE;
			CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack; //CAN_Mode_Normal; 
			CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;	
// Ajustes para APB1 a 42 MHz)
			CAN_InitStructure.CAN_BS1 = CAN_BS1_6tq;
			CAN_InitStructure.CAN_BS2 = CAN_BS2_8tq;
			CAN_InitStructure.CAN_Prescaler = 2;	
	    CAN_Init(CAN1, &CAN_InitStructure);
			
// Configura el filtro para el CAN
  CAN_FilterInitStructure.CAN_FilterNumber=0; //0..13 para CAN1
  CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;//CAN_FilterMode_IdList;//
  CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit; //CAN_FilterScale_16bit; 
	//------------
// CAN_FilterInitStructure.CAN_FilterIdHigh = 0x2460;          // 0x123
// CAN_FilterInitStructure.CAN_FilterIdLow = 0x2480;           // 0x124
// CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x24A0;      // 0x125
// CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x24C0;       // 0x126
	//-----------
  CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;
  CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;
  CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
  CAN_FilterInitStructure.CAN_FilterFIFOAssignment=0;
  CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;
  CAN_FilterInit(&CAN_FilterInitStructure);

// Configura el transmisor
  TxMessage.StdId=0x11;  // Identificador del mensaje
  TxMessage.RTR=CAN_RTR_DATA;
  TxMessage.IDE=CAN_ID_STD; // Trama de 11 bits
  TxMessage.DLC=2;					// Se TX dos Bytes
  TxMessage.Data[0]=0xCA;  	// Bytes que
  TxMessage.Data[1]=0xFE;  	// ser�n enviados (Bytes CA y FE)

  TransmitMailbox=CAN_Transmit(CAN1, &TxMessage); // Transmite el mensaje
  i = 0;
  while((CAN_TransmitStatus(CAN1, TransmitMailbox) != CANTXOK) && (i != 0xFF))
  {
    i++;
  }

  i = 0;
  while((CAN_MessagePending(CAN1, CAN_FIFO0) < 1) && (i != 0xFF))
  {
    i++;
  }
	
// Configura el receptor 
  RxMessage.StdId=0x11;  // No importa en este programa!!
  RxMessage.IDE=CAN_ID_STD;
  RxMessage.DLC=0;
  RxMessage.Data[0]=0x00; // Limpia los vectores de  RX
  RxMessage.Data[1]=0x00;
  CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);

  if (RxMessage.StdId!= 0x11) // RX espec�ficamente el mensaje enviado
  {
    return DISABLE;  // ERROR en el modo LoopBack
  }

  if (RxMessage.IDE!=CAN_ID_STD)
  {
    return DISABLE;
  }

  if (RxMessage.DLC!=2)
  {
    return DISABLE;  
  }

  if ((RxMessage.Data[0]<<8|RxMessage.Data[1])!=0xCAFE) // Son los dos Bytes?
  {
    return DISABLE;  // ERROR en el mensaje!!!
  }
  return ENABLE; // Todo ha salido bien!!!!
}
/***************************************************************************
* Funci�n     : CAN_Interrupt
* Descripci�n : Configura el CAN para recibir datos por interrupci�n.
* Retorna     : PASSED si todo a salido bien, FAILED en caso de fallo
****************************************************************************/
  int CAN_Interrupt(void)
{
  CAN_InitTypeDef        CAN_InitStructure;
  CAN_FilterInitTypeDef  CAN_FilterInitStructure;
  CanTxMsg TxMessage;
  uint32_t i = 0;

  CAN_DeInit(CAN1); // Configura el CAN1
  CAN_StructInit(&CAN_InitStructure);

		CAN_InitStructure.CAN_TTCM=DISABLE;
		CAN_InitStructure.CAN_ABOM=DISABLE;
		CAN_InitStructure.CAN_AWUM=DISABLE;
		CAN_InitStructure.CAN_NART=DISABLE;
		CAN_InitStructure.CAN_RFLM=DISABLE;
		CAN_InitStructure.CAN_TXFP=DISABLE;
		CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack;
		CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;		
// Ajustes para APB1 a 42 MHz
		CAN_InitStructure.CAN_BS1 = CAN_BS1_6tq;
		CAN_InitStructure.CAN_BS2 = CAN_BS2_8tq;
		CAN_InitStructure.CAN_Prescaler = 2;	
		CAN_Init(CAN1, &CAN_InitStructure);
	
// Configura los filtros del CAN
		CAN_FilterInitStructure.CAN_FilterNumber=1;
		CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;
		CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;
		CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;
		CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
		CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;
		CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
		CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_FIFO0;
		CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;
		CAN_FilterInit(&CAN_FilterInitStructure);

// Habilita el registro FIFO 0 para el manejo de mensajes pendientes
  CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);

// Configura el transmisor
  TxMessage.StdId=0x11;
  TxMessage.ExtId=0x1234;  // Identificador del mensaje
  TxMessage.IDE=CAN_ID_EXT;
  TxMessage.RTR=CAN_RTR_DATA;
  TxMessage.DLC=2;
  TxMessage.Data[0]=0xDE; 
  TxMessage.Data[1]=0xCA;
  CAN_Transmit(CAN1, &TxMessage);

  Result = 0xFF; // Valor por defecto del retorno
       
// Espera a la interrupci�n mientras incrementa i
  i=0;
  while((Result == 0xFF) && (i < 0xFFF))
  {
    i++;
  }
  
  if (i == 0xFFF)  	// Si i llega a este valor no
  {									// no lleg� la interrupci�n!!!!
    Result=0; 			// Reporta el fallo retorna DISABLE 		
  }
// Desabilita interrupciones
  CAN_ITConfig(CAN1, CAN_IT_FMP0, DISABLE);
		return (FunctionalState)Result;
}
/***************************************************************************
* Funci�n     : CAN1_RX0_IRQHandler
* Descripci�n : Servicio de la interrupci�n del CAN1.
* Retorna     : PASSED si encontr� el mensaje, FAILED en caso contrario
****************************************************************************/
void CAN1_RX0_IRQHandler(void)
{
 CanRxMsg RxMessage;

  RxMessage.StdId=0x00;
  RxMessage.ExtId=0x00;
  RxMessage.IDE=0;
  RxMessage.DLC=0;
  RxMessage.FMI=0;
  RxMessage.Data[0]=0x00;
  RxMessage.Data[1]=0x00;

  CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);

  if((RxMessage.ExtId==0x1234) && (RxMessage.IDE==CAN_ID_EXT)
     && (RxMessage.DLC==2) && ((RxMessage.Data[1]|RxMessage.Data[0]<<8)==0xDECA))
  {
    Result = 1; // PASSED 
  }
  else
  {
    Result = 0;  // DISABLE
  }
}

