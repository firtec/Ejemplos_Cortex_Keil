
#ifndef _HDC1000_Driver_H
#define _HDC1000_Driver_H

void Leer_Sensor(void);
unsigned int Leer_SensorID(void);
void Config_I2C1(void);
void Config_Sensor(void);

#endif
