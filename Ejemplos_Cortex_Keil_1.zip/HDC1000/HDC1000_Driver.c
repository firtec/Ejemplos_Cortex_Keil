/*************************************************************
*  Descripci�n  : Driver para el sensor HDC1000 
*                 Sensor I2C de Temperatura y Humedad.           
*  Target       : STM32F407VG
*  ToolChain    : MDK-ARM
*  IDE          : uVision 5 
*															www.firtec.com.ar
***************************************************************/
#include <stdio.h>		
#include "stm32f4xx_rcc.h"    
#include "stm32f4xx_gpio.h"		
#include <stm32f4xx.h>
#include <stm32f4xx_i2c.h>
#include "HDC1000_Driver.h"
#include "tm_stm32f4_delay.h"

#define SLAVE_ADDRESS 0x40

#define Tconstant     0.0025177     // Para 14bit de resoluci�n
#define Hconstant     0.0015259     // Para 14bit de resoluci�n

volatile unsigned int temp_value,humidity_value;
unsigned char tmp_data[12];
float temperature;
float humidity;
float dewpoint;

void Config_I2C1(void){
	
	GPIO_InitTypeDef GPIO_InitStruct;
	I2C_InitTypeDef I2C_InitStruct;
	
	// habilita APB1 reloj para I2C1
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
	// habilita reloj para el GPIO
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	
	/* El I2C1 tiene dos pares de pines posibles:
	 * 1. SCL on PB6 and SDA on PB7 
	 * 2. SCL on PB8 and SDA on PB9
	 */
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9; // referencia a los pines PB8 and PB9
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;			// pines en modo alternativo
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;		// velocidad del GPIO
	GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;			// set modo salida open drain
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;			// enable pull up resistores
	GPIO_Init(GPIOB, &GPIO_InitStruct);					// configura GPIOB
	
	// Conecta los pines elegidos (PB8 y PB9) con el puerto I2C1  
	//GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_I2C1);	// SCL
	//GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_I2C1); // SDA
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_I2C1); // SCL
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_I2C1); // SDA 
	
	// configure I2C1 
	I2C_InitStruct.I2C_ClockSpeed = 100000; 		// 100kHz
	I2C_InitStruct.I2C_Mode = I2C_Mode_I2C;			// I2C mode
	I2C_InitStruct.I2C_DutyCycle = I2C_DutyCycle_2;	// 50% duty cycle --> standard
	I2C_InitStruct.I2C_OwnAddress1 = 0x00;			// no importa en modo master
	I2C_InitStruct.I2C_Ack = I2C_Ack_Disable;		// disable ack cuando lee (se puede cambiar luego)
	I2C_InitStruct.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit; // direcci�n de 7 bit
	I2C_Init(I2C1, &I2C_InitStruct);					
	I2C_Cmd(I2C1, ENABLE);   // habilita I2C1
}

/* Esta funci�n emite una condici�n de arranque y
  * Transmite la direcci�n del esclavo + W bit R /
  *
  * Par�metros:
  * I2Cx -> I2C por ejemplo, I2C1
  * La direcci�n -> la direcci�n del esclavo 7 bits
  * Direcci�n -> la direcci�n tranmission puede ser:
  * I2C_Direction_Transmitter para el modo de transmisor
  * I2C_Direction_Receiver para el receptor
 */
void I2C_start(I2C_TypeDef* I2Cx, uint8_t address, uint8_t direction){
	// Espera hasta que I2C1 est� libre
	while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
  // Env�a I2C1 START
	I2C_GenerateSTART(I2Cx, ENABLE);
	// Espera que el esclavo reconozca la condici�n de inicio
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));	
	// Env�a al esclavo la direcci�n  de escritura 
	I2C_Send7bitAddress(I2Cx, address, direction);  
	/* Esperar para verificar que el modo Letura o Escritura ha sido reconocido */ 
	if(direction == I2C_Direction_Transmitter){
		while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));
	}
	else if(direction == I2C_Direction_Receiver){
		while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));
	}
}

/************* Esta funci�n Transmite un Byte al esclavo *************/
void I2C_write(I2C_TypeDef* I2Cx, uint8_t data)
{
	I2C_SendData(I2Cx, data);
	// Espera que termine el env�o
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
}
/************* Esta funci�n Lee un Byte desde el esclavo *************/
uint8_t I2C_read_ack(I2C_TypeDef* I2Cx){
	uint8_t data;
	// Habilitar el ACK o bit de reconocimiento
	I2C_AcknowledgeConfig(I2Cx, ENABLE);
	// Esperar hasta que la recepci�ntermine
	while( !I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED) );
	// Leer el dato desde el registro del puerto
	data = I2C_ReceiveData(I2Cx);
	return data;
}

/* Esta funci�n Lee un Byte y no espera ACK 
 * En una lectura de varios Bytes esta funci�n es la que lee el �ltimo
 * Byte */
uint8_t I2C_read_nack(I2C_TypeDef* I2Cx){
	uint8_t data;
	// Desactivar el acuse de recibo (ACK) de los datos recibidos 
	// Volver a generar la condici�n de parada despu�s del �ltimo byte recibido 
	I2C_AcknowledgeConfig(I2Cx, DISABLE);
	I2C_GenerateSTOP(I2Cx, ENABLE);
	// Esperar hasta que la recepci�ntermine
	while( !I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED) );
	// Leer el dato desde el registro del puerto
	data = I2C_ReceiveData(I2Cx);
	return data;
}

/****** Esta funci�n env�a la condici�n de stop y libera el bus ******/
void I2C_stop(I2C_TypeDef* I2Cx){
		I2C_GenerateSTOP(I2Cx, ENABLE);
}

void Leer_Sensor() {
	
	I2C_start(I2C1, SLAVE_ADDRESS<<1, I2C_Direction_Transmitter); 
	I2C_write(I2C1, 0x00); 
	I2C_stop(I2C1);
	Delayms(20); 
 	I2C_start(I2C1, SLAVE_ADDRESS<<1, I2C_Direction_Receiver); 
	tmp_data[0] = I2C_read_ack(I2C1); 
	tmp_data[1] = I2C_read_ack(I2C1);
	tmp_data[2] = I2C_read_ack(I2C1);
	tmp_data[3] = I2C_read_nack(I2C1); 
	temp_value = (tmp_data[0] << 8) + tmp_data[1];
  humidity_value = (tmp_data[2] << 8) + tmp_data[3];
  temperature = ((float)temp_value * Tconstant)-40;
  humidity = (float)humidity_value * Hconstant;
}

unsigned int Leer_SensorID() {
  unsigned int id_value;
	tmp_data[0] = 0;
	tmp_data[1] = 0;
	I2C_start(I2C1, SLAVE_ADDRESS<<1, I2C_Direction_Transmitter); 
	I2C_write(I2C1, 0xFF); 
	I2C_stop(I2C1);
	I2C_start(I2C1, SLAVE_ADDRESS<<1, I2C_Direction_Receiver); 
	tmp_data[0] = I2C_read_ack(I2C1); 
	tmp_data[1] = I2C_read_nack(I2C1); 
	id_value = (tmp_data[0] << 8) + tmp_data[1];
	return id_value;
}
/**** Esta funci�n configura el registro de control del sensor ******/
void Config_Sensor(){
	  I2C_start(I2C1, SLAVE_ADDRESS<<1, I2C_Direction_Transmitter); 
	  I2C_write(I2C1, 0x02); // Registro de control
		I2C_write(I2C1, 0x10); // Secuencia de lecturas (bit 12)
	  I2C_write(I2C1, 0x00); // Bit del 0-7 deben ser ceros.
		I2C_stop(I2C1); // stop
		
}	




