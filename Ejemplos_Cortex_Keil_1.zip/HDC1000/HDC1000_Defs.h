
//#define HDC1000_I2C_ADDR        0x40                                            //Sensor address
  //  #define HDC1000_I2C_ADDR        0x20                                                                                //Jumper ADR0 = 0
                                                                                //Jumper ADR1 = 0
//#define TEMP_I2C_ADDR           0x00
//#define HUMIDITY_I2C_ADDR       0x01
//#define CONFIG_I2C_ADDR         0x02
//#define DEVICEID_I2C_ADDR       0xFF

//#define ID_NUMBER               0x1000

//#define Tconstant               0.0025177              //For 14bit resolution
//#define Hconstant               0.0015259              //For 14bit resolution
