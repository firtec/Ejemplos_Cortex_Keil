/*************************************************************
*  Nombre       : AD_UnCanal.c
*  Descripci�n  : Midiendo por un solo canal (AN6 PA6).           
*  Target       : STM32F407VG
*  ToolChain    : MDK-ARM
*  IDE          : uVision 4 
*	 www.firtec.com.ar
***************************************************************/
#include "stm32f4xx.h"
#include <stdio.h>
#include "tm_stm32f4_hd44780.h"
#include "tm_stm32f4_delay.h"


void ADC_Configuration(void);
void Leer_Conversor(void);


char floatStr[10];
uint16_t a = 0, M0=0, conversion =0;
uint32_t muestras = 0;
float voltaje = 0;
	
int main(void){
	
ADC_Configuration();
TM_HD44780_Init(16,2);
Delayms(200); 
	
	   TM_HD44780_Puts(0,0,"AN6:");		
		 TM_HD44780_Puts(0,1,"AN6:");		
	
while (1){
	sprintf(floatStr,"%04d", conversion);
	TM_HD44780_Puts(4,0,floatStr);
	sprintf(floatStr,"%2.2f", voltaje);
	TM_HD44780_Puts(4,1,floatStr);
	Leer_Conversor();
  }
}
//************** Configura el ADC1 y el pin anal�gico ************************
void ADC_Configuration(void)
{
	ADC_InitTypeDef       ADC_InitStructure;				// Se encuentra en stm32f4xx_adc.c
  ADC_CommonInitTypeDef ADC_CommonInitStructure;	// Se encuentra en stm32f4xx_adc.c
  GPIO_InitTypeDef      GPIO_InitStructure;				// Estructura para configurar el PIN
 /* Habilita reloj para ADC1 y el puerto A */
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);	// Activa bus APB2 para el conversor
 RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);// Activa bus AHB1 para el puerto	
 
	/* Configura el pin GPA6 como anal�gico para el ADC1 ******************************/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; 
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
 
	/* Configuraci�n general del ADC  *************************************************/
  ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;  // Lee desde el canal directamente
 	ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div6; //APB2 84Mhz/6 = 14hz clock max. del adc
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
  ADC_CommonInit(&ADC_CommonInitStructure);
 
	/* Configura el ADC1 (7 parametros de configuraci�n) ******************************/
	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
   ADC_InitStructure.ADC_ScanConvMode = DISABLE;
   ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
   ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
	
	 ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;   
   ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
   ADC_InitStructure.ADC_NbrOfConversion = 1;
	 ADC_Init(ADC1, &ADC_InitStructure); // Hace efectiva la configuraci�n
	 ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 1,ADC_SampleTime_144Cycles);
   ADC_Cmd(ADC1, ENABLE); // Habilita el ADC1
}
// ********************* Funci�n que lee el conversor A/D *************************
void Leer_Conversor(void)
{             // El canal 13 (PC3) se puede vincular a los tres ADC 
	
  //ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 1,ADC_SampleTime_144Cycles);
	ADC_SoftwareStartConv(ADC1);  // Inicia la conversi�n
  while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET); // Espera que termine	
  M0 += ADC_GetConversionValue(ADC1);  
	
	if(15==muestras++){ 		// Se tomaron 16 muestras?
     conversion = M0/16;  // Se busca el promedio de 16 muestras
       M0 = 0;        		// Variables inicializadas para las siguientes
       muestras =0;   		// muestras del conversor.
			voltaje = (conversion*3.3)/4096;  //(AD_value/4096)*3.3
	}
}

/*
Para usar sprinf se debe desabilitar Folating Point Hardware desde la opci�nes del proyecto
*/
