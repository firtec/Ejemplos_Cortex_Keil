/**********************************************************************
  * @file    httpd_cg_ssi.c
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    31-October-2011
  * @brief   Webserver SSI and CGI handlers
  *********************************************************************/
  
#include "lwip/debug.h"
#include "httpd.h"
#include "lwip/tcp.h"
#include "fs.h"
#include "main.h"

#include <string.h>
#include <stdlib.h>

// Declara funci�n que recibe los comandos CGI y controla los LED�s
const char * LEDS_CGI_Handler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]);
// Pide el estado de los leds mediante leds.cgi declarado en STM32F4x7LED.html
const tCGI LEDS_CGI={"/leds.cgi", LEDS_CGI_Handler};

// Tabla CGI, solo un CGI usado
tCGI CGI_TAB[1];


//***********************************************************************
// Esta funci�n interpreta los comandos CGI para el control de los LED�s
//************************************************************************ 
const char * LEDS_CGI_Handler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[])
{
/****** Codigo en la pagina web *******************
<form method="get" action="/leds.cgi">
<input value="1" name="led" type="checkbox">LED1<br>
<input value="2" name="led" type="checkbox">LED2<br>
<input value="3" name="led" type="checkbox">LED3<br>
<input value="4" name="led" type="checkbox">LED4<br>
****************************************************/
uint32_t i=0;
	if (iIndex==0) 
  {
// Si el parametro enviado es cero todos los LED's apagados!!!
    STM_EVAL_LEDOff(LED1);  // Verde
    STM_EVAL_LEDOff(LED2);  // Naranja
    STM_EVAL_LEDOff(LED3);  // Rojo
    STM_EVAL_LEDOff(LED4);  // Azul
	} 
for (i=0; i<iNumParams; i++) // Cantidad de casilleros marcados.
    {
// Verifica que el parametro enviado sea "led" si esto 
// es correcto se pasa a verificar cual LED esta activo.
   if (strcmp(pcParam[i] , "led")==0){
// Si e valor asociado al comando es 1 activar LED Verde
        if(strcmp(pcValue[i], "1") ==0) 
          STM_EVAL_LEDOn(LED1);        
// Si e valor asociado al comando es 2 activar LED Naranja
        else if(strcmp(pcValue[i], "2") ==0) 
          STM_EVAL_LEDOn(LED2);       
// Si e valor asociado al comando es 3 activar LED Rojo
        else if(strcmp(pcValue[i], "3") ==0) 
          STM_EVAL_LEDOn(LED3);      
// Si e valor asociado al comando es 4 activar LED Azul
        else if(strcmp(pcValue[i], "4") ==0) 
          STM_EVAL_LEDOn(LED4);
      }
    }
  //}
  /* uri to send after cgi call*/
  return "/STM32F4x7LED.html";  
}

//********************************************
// * Inicializa el controlador SSI 
//********************************************
void httpd_ssi_init(void)
{  
/* No hay comandos SSI en este programa	*/
}
//********************************************
//  Inicializa el controlador CGI
//  Esta funci�n es invocada en httpd.c y es la encargada
//  de pedir el estado 
//********************************************
void httpd_cgi_init(void)
{ 
  /* configure CGI handlers (LEDs control CGI) */
 CGI_TAB[0] = LEDS_CGI;
 http_set_cgi_handlers(CGI_TAB, 1);
}

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
