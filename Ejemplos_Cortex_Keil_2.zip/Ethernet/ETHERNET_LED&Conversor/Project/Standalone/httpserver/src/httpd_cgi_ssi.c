/**
  ******************************************************************************
  * @file    httpd_cg_ssi.c
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    11-May-2015
  * @brief   Webserver SSI and CGI handlers
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/


#include "lwip/debug.h"
#include "httpd.h"
#include "lwip/tcp.h"
#include "fs.h"
#include "main.h"

#include <string.h>
#include <stdlib.h>

tSSIHandler ADC_Page_SSI_Handler;
uint32_t ADC_not_configured=1;

/* Se usar� el caracter t como tag del SSI */
char const* TAGCHAR="t";
char const** TAGS=&TAGCHAR;

// Declara funci�n que recibe los comandos CGI y controla los LED�s
const char * LEDS_CGI_Handler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]);
// Pide el estado de los leds mediante leds.cgi declarado en STM32F4x7LED.html
const tCGI LEDS_CGI={"/leds.cgi", LEDS_CGI_Handler};

// Tabla CGI, solo un CGI usado
tCGI CGI_TAB[1];

//***********************************************************
//	Funci�n que configura el ADC (Pines, resoluci�n, etc)
//************************************************************
static void ADC_Configuration(void)
{
  ADC_InitTypeDef ADC_InitStructure;
  ADC_CommonInitTypeDef ADC_CommonInitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Habilita ADC1 clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

  /* Configura ADC Canal 6 GPIOA pin 6 como entrada anal�gica */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* ADC Common Init */
  ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div6;
  ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles; 
  ADC_CommonInit(&ADC_CommonInitStructure); 

  /* ADC1 Configuraci�n ------------------------------------------------------*/
  ADC_StructInit(&ADC_InitStructure);
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None; 
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfConversion = 1;
  ADC_Init(ADC1, &ADC_InitStructure);

	ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 1, ADC_SampleTime_56Cycles);
	ADC_Cmd(ADC1, ENABLE);
	ADC_SoftwareStartConv(ADC1);
}

//-------------------------------------------------------------
//  ADC_Handler: controlador SSI para la pagina del ADC
//
//--------------------------------------------------------------
u16_t ADC_Handler(int iIndex, char *pcInsert, int iInsertLen)
{
  //* S�lo hay un tag SSI iIndex = 0 
  if (iIndex ==0)
  {  
    char Miles=0, Centena=0, Decena=0, Unidad=0; 
    uint32_t ADCVal = 0;        

 // Configurar ADC si no est� configurado 
     if (ADC_not_configured ==1)       
     {
        ADC_Configuration();
        ADC_not_configured=0;
     }   
  // Obtiene el valor del Conversor ADC1    
		  ADCVal = ADC_GetConversionValue(ADC1);
 // Convierte a voltaje en pasos de 0.8 mV
     ADCVal = (uint32_t)(ADCVal * 0.8);  		 
 // Ajusto el valor de los digitos 
     Miles= ADCVal/1000;
     Centena= (ADCVal-(Miles*1000))/100 ;
     Decena= (ADCVal-((Miles*1000)+(Centena*100)))/10;
     Unidad= ADCVal -((Miles*1000)+(Centena*100)+ (Decena*10));     
 // Prepara los datos para insertarlos en el html
     *pcInsert       = (char)(Miles+0x30);
     *(pcInsert + 1) = (char)(Centena+0x30);
     *(pcInsert + 2) = (char)(Decena+0x30);
     *(pcInsert + 3) = (char)(Unidad+0x30);
    
   // 4 caracteres han sido insertados en el html
		return 4;
  }
  return 0;
}

//***********************************************************************
// Esta funci�n interpreta los comandos CGI para el control de los LED�s
//************************************************************************ 
const char * LEDS_CGI_Handler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[])
{
  uint32_t i=0;
  if (iIndex==0)
  {
  // Si el parametro enviado es cero todos los LED's apagados!!!
    STM_EVAL_LEDOff(LED1);  // Verde
    STM_EVAL_LEDOff(LED2);  // Naranja
    STM_EVAL_LEDOff(LED3);  // Rojo
    STM_EVAL_LEDOff(LED4);  // Azul  
    
   // Cantidad de casilleros marcados.
    for (i=0; i<iNumParams; i++)
    {
 // Verifica que el parametro enviado sea "led" si esto 
// es correcto se pasa a verificar cual LED esta activo.
   if (strcmp(pcParam[i] , "led")==0){
// Si e valor asociado al comando es 1 activar LED Verde
        if(strcmp(pcValue[i], "1") ==0) 
          STM_EVAL_LEDOn(LED1);        
// Si e valor asociado al comando es 2 activar LED Naranja
        else if(strcmp(pcValue[i], "2") ==0) 
          STM_EVAL_LEDOn(LED2);       
// Si e valor asociado al comando es 3 activar LED Rojo
        else if(strcmp(pcValue[i], "3") ==0) 
          STM_EVAL_LEDOn(LED3);      
// Si e valor asociado al comando es 4 activar LED Azul
        else if(strcmp(pcValue[i], "4") ==0) 
          STM_EVAL_LEDOn(LED4);
      }
    }
  }
 // Regresa a la pagina de origen
  return "/STM32F4x7LED.html";  
}

/**
 * Initialize SSI handlers
 */
void httpd_ssi_init(void)
{  
  /* configure SSI handlers (ADC page SSI) */
  http_set_ssi_handler(ADC_Handler, (char const **)TAGS, 1);
}

//********************************************
//  Inicializa el controlador CGI
//  Esta funci�n es invocada en httpd.c y es la encargada
//  de pedir el estado 
//********************************************
void httpd_cgi_init(void)
{ 
  /* configure CGI handlers (LEDs control CGI) */
 CGI_TAB[0] = LEDS_CGI;
 http_set_cgi_handlers(CGI_TAB, 1);
}


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
