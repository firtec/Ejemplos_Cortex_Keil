/*****************************************************************************
*  Proyecto     : Ethernet_LED&Conversor
*  Descripci�n  : Control de los led y lectura del conversor AD.           
*  Target       : STM32F407VG entrenadora Discovery.
*  ToolChain    : MDK-ARM
*  IDE          : uVision 4 
*	 www.firtec.com.ar
********************************************************************************/

#include "stm32f4x7_eth.h"
#include "netconf.h"
#include "main.h"
#include "httpd.h"
#include "serial_debug.h"

#define SYSTEMTICK_PERIOD_MS  10

__IO uint32_t LocalTime = 0; // Variable usada para crear tiempos de 10ms 
uint32_t timingdelay;

void LED_Init(void);

//-------------- PROGRAMA PRINCIPAL ----------------------
int main(void)
{
    
#ifdef SERIAL_DEBUG
  DebugComPort_Init();
#endif
	 
  LED_Init(); // Configura los LED's
	
  ETH_BSP_Config(); // Configure Ethernet (GPIOs, clocks, MAC, DMA) 

  LwIP_Init();  	// Inicializa el stack LwIP 
  httpd_init(); 	// Inicia el webserver 

  while (1)  // Bucle infinito
  {  
    if (ETH_CheckFrameReceived())  // Verifica si hay paquetes recibidos
    { 
      LwIP_Pkt_Handle(); // Procesa los paquetes
    }
    LwIP_Periodic_Handle(LocalTime);   // Tiks periodicos para LwIP
  }   
}
// ---- Rutinas de tiempo para el Stack ------
void Delay(uint32_t nCount){
  timingdelay = LocalTime + nCount;  
  while(timingdelay > LocalTime)
    {     
  }
}

void Time_Update(void)
{
  LocalTime += SYSTEMTICK_PERIOD_MS;
}

// -----  Configura los LED's de la placa -----
void LED_Init(void){
    STM_EVAL_LEDInit(LED1);
  STM_EVAL_LEDInit(LED2);
  STM_EVAL_LEDInit(LED3);
  STM_EVAL_LEDInit(LED4); 
}

#ifdef  USE_FULL_ASSERT

void assert_failed(uint8_t* file, uint32_t line)
{
    while (1)
  {}
}
#endif

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
